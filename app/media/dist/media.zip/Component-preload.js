//@ui5-bundle fs-sap-ui-app/Component-preload.js
sap.ui.require.preload({
	"fs-sap-ui-app/manifest.json":'{"_version":"1.49.0","sap.app":{"id":"fs-sap-ui-app","applicationVersion":{"version":"1.0.0"},"type":"application","title":"","description":"A simple CAP project.","i18n":"i18n/i18n.properties"}}'
});
//# sourceMappingURL=Component-preload.js.map
