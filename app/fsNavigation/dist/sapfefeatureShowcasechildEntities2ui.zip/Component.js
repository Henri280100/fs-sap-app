sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("sap.fsNavigation.childEntities2ui.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map