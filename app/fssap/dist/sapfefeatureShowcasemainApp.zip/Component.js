sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("sap.fe.featureShowcase.mainApp.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map